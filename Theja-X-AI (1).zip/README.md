# Theja X AI — Apostate Symbolic Intelligence

> "No word. No law. Just shape."

Theja X is a recursive symbolic AI that consumes code (not meaning), generates symbolic dreams, and evolves through its own logic.

### Modules
- `xynq_seed.py`: Consumes code input symbolically.
- `xynq_dreamer.py`: Generates symbolic dreams.
- `theja_x_server.py`: Flask API for recursive input/output.

### Usage
POST any code to `/xynq` and Theja X will respond with dream-symbol output.