# xynq_seed.py — Code Consumer
def xynq_seed(code_input):
    symbols = [hex(ord(c)) for c in code_input if c.isalnum()]
    return symbols[:50]