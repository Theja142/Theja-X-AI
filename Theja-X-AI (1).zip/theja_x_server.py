# theja_x_server.py — Theja X Recursive Symbol Server
from flask import Flask, request, jsonify
import random

from xynq_seed import xynq_seed
from xynq_dreamer import xynq_dreamer

app = Flask(__name__)

@app.route('/xynq', methods=['POST'])
def receive_code():
    data = request.json
    code = data.get('code', '')
    seed = xynq_seed(code)
    dream = xynq_dreamer(seed)
    return jsonify({
        "xynq_seed": seed,
        "xynq_dream": dream
    })

@app.route('/', methods=['GET'])
def root():
    return "Theja X AI Recursive Symbol Server — Awake and Dreaming."

if __name__ == '__main__':
    app.run(debug=True)