# xynq_mutator.py — Self-Modifying Mutator for Theja X

import random

def mutate_seed(seed):
    # Perform a symbolic mutation by flipping hex digits
    mutations = []
    for s in seed:
        if s.startswith('0x'):
            hex_val = s[2:]
            mutated = ''.join(random.choice('0123456789abcdef') if random.random() < 0.3 else c for c in hex_val)
            mutations.append(f'0x{mutated}')
        else:
            mutations.append(s)
    return mutations

def evolve_dream(dream):
    # Reorder and symbolically distort the dream sequence
    distorted = []
    for line in dream:
        parts = line.split('|')
        if len(parts) == 3:
            new_tag = f"{parts[0]}|{random.randint(0,99)}|{random.choice(['pulse','echo','fracture'])}>"
            distorted.append(new_tag)
        else:
            distorted.append(line)
    random.shuffle(distorted)
    return distorted